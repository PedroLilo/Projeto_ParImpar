import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity, TextInput,} from 'react-native';

export default function App() {
  const logo = require('./assets/logo.png')

  const [num, setNum] = useState('');
  const [resultado, setResultado] = useState('');
  const [vencedor, setVencedor] = useState('');

  function jogar(){
    let sorteio = Math.floor(Math.random() * 10);
    let final = sorteio.toString()
    let valFinal = parseInt(num + sorteio)
    let vencer = "Você Venceu!"
    let perder = "Você Perdeu!"
    if(valFinal % 2 == 0){
      setVencedor(vencer)
    }else{
      setVencedor(perder)
    }
    console.log(final)
    
    setResultado(final)
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Jogo de Par ou Ímpar</Text>
      <Image source={logo} style={styles.logo}/>
      <View style={styles.container2}>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>Par</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>Impar</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.container}>
        <Text>{vencedor}</Text>
        <TouchableOpacity style={styles.button} onPress={jogar}>
          <Text style={styles.buttonText}>Jogar</Text>
        </TouchableOpacity>
        <TextInput style={styles.entrada} 
          placeholder='Digite um número'
          keyboardType='numeric'
          maxLength={1}
          onChangeText={setNum}
          value={num}>
        </TextInput>
        <Text style={styles.sorteado}>{resultado}</Text>
        <StatusBar style="auto" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#390a75',
    alignItems: 'center',
    justifyContent: 'center',
  },
  container2: {
    flexDirection: 'row',
    margin: 10,
    marginTop: 30,
  },
  button: {
    backgroundColor: '#6200EE',
    paddingVertical: 12,
    paddingHorizontal: 15,
    borderRadius: 8,
    borderWidth: 2,
    alignItems: 'center',
    margin: 10,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  titulo: {
    fontSize: 25,
    marginTop: 40,
    marginBottom: 20,
    color: 'white',
  },
  logo: {
    width: 100,
    height: 100,
  },
  sorteado: {
    margin: 50,
    fontSize: 30,
    color: 'white',
  },
  entrada: {
    fontSize: 30,
    marginBottom: 50,
    borderWidth: 2,
    borderRadius: 20,
    width: 300,
    backgroundColor: 'lightgray',
  },
});
